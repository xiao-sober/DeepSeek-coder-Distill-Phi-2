import torch
import torch.nn.functional as F
from torch.optim import AdamW
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset
from torch.utils.data import DataLoader
import math

# -------------------
# 1. 加载模型（本地路径）
# -------------------
teacher_model_path = "deepseek-coder-6.7b-instruct"
student_model_path = "phi-2"
dataset_path = "dataset/alpaca-cleaned/alpaca_data_cleaned.json"

# 统一使用教师模型的tokenizer
tokenizer = AutoTokenizer.from_pretrained(teacher_model_path)

# 加载学生模型时添加词汇表扩展
student_model = AutoModelForCausalLM.from_pretrained(
    student_model_path,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True
)

# 加载教师模型（Deepseek-Coder-6.7B）
teacher_model = AutoModelForCausalLM.from_pretrained(
    teacher_model_path,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True
).eval()  # 设为 eval 模式，减少显存占用

# 仅当词汇表大小不匹配时调整
if len(tokenizer) != student_model.config.vocab_size:
    student_model.resize_token_embeddings(len(tokenizer))
    print(f"Resized embeddings to {len(tokenizer)} tokens")

# -------------------
# 2. 处理 Alpaca-cleaned 数据
# -------------------
# 加载数据集（Alpaca格式）
dataset = load_dataset(
    "json",
    data_files=dataset_path,
    split="train",
    verification_mode="no_checks"
)

# 划分训练集和验证集（90%训练，10%验证）
split_dataset = dataset.train_test_split(test_size=0.1)
train_dataset = split_dataset["train"]
val_dataset = split_dataset["test"]

# 预处理函数调整（Alpaca数据格式）
def preprocess_function(example):
    question = example["instruction"]
    if example.get("input", ""):
        question += "\n" + example["input"]
    # 添加明确的答案分隔符
    return {
        "text": question + "\n### Answer: " + example["output"],
        "question": question
    }

processed_train = train_dataset.map(preprocess_function, remove_columns=train_dataset.column_names)
processed_val = val_dataset.map(preprocess_function, remove_columns=val_dataset.column_names)

# Tokenization
def tokenize_function(example):
    tokenized = tokenizer(
        example["text"],
        max_length=512,
        truncation=True,
        padding="max_length",
        return_tensors="pt"
    )

    # 创建labels并设置问题部分为忽略索引
    labels = tokenized.input_ids.clone()
    sep_phrase = "\n### Answer:"
    sep_token_ids = tokenizer.encode(sep_phrase, add_special_tokens=False)

    # 查找分隔符位置
    for i in range(len(labels)):
        seq = labels[i].tolist()
        sep_pos = None
        # 滑动窗口查找分隔符
        for j in range(len(seq) - len(sep_token_ids) + 1):
            if seq[j:j + len(sep_token_ids)] == sep_token_ids:
                sep_pos = j + len(sep_token_ids)
                break
        if sep_pos:
            labels[i, :sep_pos] = -100  # 忽略问题部分
        else:
            labels[i, :] = -100  # 无效样本全忽略

    return {
        "input_ids": tokenized.input_ids,
        "attention_mask": tokenized.attention_mask,
        "labels": labels
    }

tokenized_train = processed_train.map(tokenize_function, batched=True)
tokenized_val = processed_val.map(tokenize_function, batched=True)

# 关键修复：设置数据集格式为PyTorch张量
tokenized_train.set_format(type='torch', columns=['input_ids', 'attention_mask', 'labels'])
tokenized_val.set_format(type='torch', columns=['input_ids', 'attention_mask', 'labels'])

train_dataloader = DataLoader(tokenized_train, batch_size=2, shuffle=True)
val_dataloader = DataLoader(tokenized_val, batch_size=2)

# -------------------
# 3. 知识蒸馏损失函数
# -------------------
def distillation_loss(student_logits, teacher_logits, labels, temperature=3.0, alpha=0.7):
    # 添加数值稳定处理
    min_vocab = min(student_logits.size(-1), teacher_logits.size(-1))
    student_logits = student_logits[..., :min_vocab]
    teacher_logits = teacher_logits[..., :min_vocab]

    # 有效token掩码（排除padding和忽略位置）
    valid_mask = (labels != -100) & (labels < min_vocab)
    valid_mask = valid_mask.float()

    # 温度缩放加稳定常数
    eps = 1e-7
    teacher_probs = F.softmax(teacher_logits / temperature + eps, dim=-1)
    student_log_probs = F.log_softmax(student_logits / temperature + eps, dim=-1)

    # KL散度计算
    kl_loss = F.kl_div(
        student_log_probs,
        teacher_probs.detach(),  # 切断教师梯度
        reduction="none"
    ).sum(-1)

    kl_loss = (kl_loss * valid_mask).sum() / valid_mask.sum().clamp(min=1e-7)
    kl_loss *= (temperature ** 2)

    # 交叉熵损失
    ce_loss = F.cross_entropy(
        student_logits.view(-1, student_logits.size(-1)),
        labels.view(-1),
        ignore_index=-100,
        reduction="none"
    ).view_as(labels)

    ce_loss = (ce_loss * valid_mask).sum() / valid_mask.sum().clamp(min=1e-7)

    return alpha * kl_loss + (1 - alpha) * ce_loss

# -------------------
# 4. 训练设置
# -------------------
optimizer = AdamW(student_model.parameters(), lr=2e-5)
num_epochs = 3
gradient_accumulation_steps = 8  # 适用于显存有限情况

# -------------------
# 5. 评估困惑度（Perplexity）
# -------------------
def evaluate_perplexity(model, dataloader):
    model.eval()
    total_loss = 0
    total_tokens = 0

    with torch.no_grad():
        for batch in dataloader:
            inputs = {
                "input_ids": batch["input_ids"].to("cuda"),
                "attention_mask": batch["attention_mask"].to("cuda"),
                "labels": batch["labels"].to("cuda")
            }

            outputs = model(**inputs)
            loss = outputs.loss
            active_tokens = (inputs["labels"] != -100).sum()

            total_loss += loss.item() * active_tokens.item()
            total_tokens += active_tokens.item()

    return math.exp(total_loss / total_tokens)

# 在训练循环后调用评估
val_perplexity = evaluate_perplexity(student_model, val_dataloader)
print(f"Validation Perplexity: {val_perplexity:.4f}")

# -------------------
# 6. 训练循环
# -------------------
student_model.gradient_checkpointing_enable()

for epoch in range(num_epochs):
    student_model.train()
    epoch_train_loss = 0

    for step, batch in enumerate(train_dataloader):
        with torch.amp.autocast("cuda"):  # 低精度训练
            inputs = {k: v.to("cuda", non_blocking=True) for k, v in batch.items()}

            # 教师模型前向传播（减少显存占用）
            with torch.no_grad():
                teacher_outputs = teacher_model(**inputs)

            # 学生模型前向传播
            student_outputs = student_model(**inputs)

            # 计算蒸馏损失
            loss = distillation_loss(
                student_logits=student_outputs.logits,
                teacher_logits=teacher_outputs.logits,
                labels=inputs["labels"]
            )

        # 反向传播
        (loss / gradient_accumulation_steps).backward()
        epoch_train_loss += loss.item()

        # 梯度累积
        if (step + 1) % gradient_accumulation_steps == 0:
            optimizer.step()
            optimizer.zero_grad()

        # 释放显存
        del inputs, teacher_outputs, student_outputs
        torch.cuda.empty_cache()

        # 训练日志
        if step % 100 == 0:
            print(f"Epoch {epoch+1} Step {step} Loss: {loss.item():.4f}")

    # 计算验证集 PPL
    val_perplexity = evaluate_perplexity(student_model, val_dataloader)
    print(f"Epoch {epoch+1} Validation Perplexity: {val_perplexity:.4f}")

# -------------------
# 7. 保存模型
# -------------------
output_dir = "distilled_phi2"
student_model.save_pretrained(output_dir)
tokenizer.save_pretrained(output_dir)
print("模型已保存！🚀")

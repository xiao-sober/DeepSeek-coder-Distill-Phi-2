from modelscope import AutoModelForCausalLM, AutoTokenizer

# 输入模型路径）
model_name = "./deepseek-coder-6.7b-instruct"

# 实例化模型（注意 trust_remote_code）
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype="auto",
    device_map="auto",
    low_cpu_mem_usage=True,
    trust_remote_code=True  # 必须添加此参数
)

# 实例化 tokenizer
tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    trust_remote_code=True,
    use_fast=False,  # 推荐关闭 fast tokenizer
    padding_side="left"  # 代码生成建议左对齐
)

# 创建符合 DeepSeek-Coder 格式的消息
prompt = "请给我来一个实现bp神经网络的代码。"
messages = [
    {"role": "user", "content": prompt}
    # DeepSeek-Coder 通常不需要 system prompt
]

# 应用模板（注意不同模型的模板格式）
text = tokenizer.apply_chat_template(
    messages,
    tokenize=False,
    add_generation_prompt=True
)
model_inputs = tokenizer(text, return_tensors="pt").to(model.device)

# 生成参数优化（针对代码模型调整）
generated_ids = model.generate(
    **model_inputs,
    max_new_tokens=512,
    temperature=0.9,  # 增加创造性
    top_p=0.95,
    do_sample=True,
    eos_token_id=tokenizer.eos_token_id
)

# 解码时跳过模板内容
response = tokenizer.decode(
    generated_ids[0][len(model_inputs.input_ids[0]):],
    skip_special_tokens=True
)

print(response)
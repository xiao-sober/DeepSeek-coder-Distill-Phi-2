import torch
from datasets import load_dataset
from torch.utils.data import DataLoader
from transformers import AutoModelForCausalLM, AutoTokenizer

# -------------------
# 1. 加载模型（本地路径）
# -------------------
teacher_model_path = "deepseek-coder-6.7b-instruct"
student_model_path = "phi-2"
dataset_path = "dataset/alpaca-cleaned/alpaca_data_cleaned.json"

# 统一使用教师模型的tokenizer
tokenizer = AutoTokenizer.from_pretrained(teacher_model_path)

# 加载学生模型时添加词汇表扩展
student_model = AutoModelForCausalLM.from_pretrained(
    student_model_path,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True
)

# 加载教师模型（Deepseek-Coder-6.7B）
teacher_model = AutoModelForCausalLM.from_pretrained(
    teacher_model_path,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True
).eval()  # 设为 eval 模式，减少显存占用

# 仅当词汇表大小不匹配时调整
if len(tokenizer) != student_model.config.vocab_size:
    student_model.resize_token_embeddings(len(tokenizer))
    print(f"Resized embeddings to {len(tokenizer)} tokens")


# 检查两个模型的注意力头尺寸
# assert teacher_model.config.hidden_size % teacher_model.config.num_attention_heads == 0
# assert student_model.config.hidden_size % student_model.config.num_attention_heads == 0
#
# # 检查位置编码兼容性
# print(f"Teacher position embedding: {type(teacher_model.model.embed_positions)}")
# print(f"Student position embedding: {type(student_model.model.embed_positions)}")
#
# # 如果使用不同tokenizer，需要检查特殊token对齐
# print(f"Teacher EOS token: {tokenizer.eos_token_id}")
# print(f"Student EOS token: {student_model.config.eos_token_id}")
#
# # 必要时进行token映射
# if tokenizer.eos_token_id != student_model.config.eos_token_id:
#     student_model.config.eos_token_id = tokenizer.eos_token_id
#     print(f"Adjusted student EOS token to {tokenizer.eos_token_id}")


# 加载数据集（Alpaca格式）
dataset = load_dataset(
    "json",
    data_files=dataset_path,
    split="train",
    verification_mode="no_checks"
)

# 划分训练集和验证集（90%训练，10%验证）
split_dataset = dataset.train_test_split(test_size=0.1)
train_dataset = split_dataset["train"]
val_dataset = split_dataset["test"]

# 预处理函数调整（Alpaca数据格式）
def preprocess_function(example):
    # 组合instruction和input
    question = example["instruction"]
    if example.get("input", ""):
        question += "\n" + example["input"]

    return {
        "question": question,
        "answer": example["output"]
    }

processed_train = train_dataset.map(preprocess_function, remove_columns=train_dataset.column_names)
processed_val = val_dataset.map(preprocess_function, remove_columns=val_dataset.column_names)

# Tokenization
def tokenize_function(example):
    # 合并instruction和input
    instruction = example["instruction"]
    input_text = example["input"] if example["input"] else ""
    question = f"{instruction}\n{input_text}".strip()

    # 构建完整训练格式：[Question] + [Answer]
    full_text = f"{question}{tokenizer.eos_token}{example['output']}{tokenizer.eos_token}"

    # 统一编码
    tokenized = tokenizer(
        full_text,
        max_length=512,
        truncation=True,
        padding="max_length",
        return_tensors="pt"
    )

    # 创建标签掩码（仅计算答案部分的loss）
    labels = tokenized["input_ids"].clone()
    # 计算问题部分的token长度（包括EOS）
    question_tokens = tokenizer(
        f"{question}{tokenizer.eos_token}",
        max_length=512,
        truncation=True,
        return_tensors="pt"
    )
    input_length = question_tokens["input_ids"].size(1)

    # 掩码输入部分和填充符
    labels[:, :input_length] = -100  # 忽略输入部分的loss
    labels[labels == tokenizer.pad_token_id] = -100  # 忽略padding部分的loss

    return {
        "input_ids": tokenized["input_ids"][0],
        "attention_mask": tokenized["attention_mask"][0],
        "labels": labels[0]
    }

tokenized_train = processed_train.map(tokenize_function, batched=True)
tokenized_val = processed_val.map(tokenize_function, batched=True)

# 关键修复：设置数据集格式为PyTorch张量
tokenized_train.set_format(type='torch', columns=['input_ids', 'attention_mask', 'labels'])
tokenized_val.set_format(type='torch', columns=['input_ids', 'attention_mask', 'labels'])

train_dataloader = DataLoader(tokenized_train, batch_size=2, shuffle=True)
val_dataloader = DataLoader(tokenized_val, batch_size=2)

# 检查单个样本的数据处理
sample = dataset["train"][0]
tokenized = tokenize_function(sample)

print("原始样本:")
print(f"Instruction: {sample['instruction']}")
print(f"Output: {sample['output'][:50]}...\n")

print("处理后的张量:")
print(f"Input IDs shape: {tokenized['input_ids'].shape}")
print(f"Labels mask ratio: {(tokenized['labels'] == -100).float().mean():.2f}")

# 解码验证
print("\n解码结果:")
print("Input部分:", tokenizer.decode(tokenized["input_ids"][:tokenized["input_ids"].tolist().index(tokenizer.eos_token_id)+1]))
print("Target部分:", tokenizer.decode(torch.where(tokenized["labels"] != -100, tokenized["input_ids"], tokenizer.pad_token_id)))
from modelscope import AutoModelForCausalLM, AutoTokenizer

# 输入模型本地路径
model_name = "./phi-2"

# 实例化模型（注意参数差异）
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    torch_dtype="auto",
    device_map="auto",
    low_cpu_mem_usage=True,
    # Phi-2 不需要 trust_remote_code
)

# 实例化 tokenizer（需特殊处理）
tokenizer = AutoTokenizer.from_pretrained(
    model_name,
    padding_side="left"  # 必须左对齐
)
tokenizer.pad_token = tokenizer.eos_token  # 显式设置 pad_token

# 创建符合 Phi-2 格式的消息（无角色标记）
prompt = "请给我来一个实现bp神经网络的代码。\n答案："  # 添加明确的指令分隔符
messages = prompt  # Phi-2 不需要对话格式

# 直接分词（无需 apply_chat_template）
model_inputs = tokenizer(
    messages,
    return_tensors="pt",
    padding=True
).to(model.device)

# 生成参数优化（针对推理模型调整）
generated_ids = model.generate(
    **model_inputs,
    max_new_tokens=200,  # Phi-2 上下文较短（2K tokens）
    temperature=0.7,
    top_p=0.9,
    repetition_penalty=1.2,
    do_sample=True,
    pad_token_id=tokenizer.eos_token_id  # 必须指定
)

# 直接解码完整输出
response = tokenizer.decode(
    generated_ids[0],
    skip_special_tokens=True
)

# 提取新生成部分（可选）
new_response = response[len(prompt):]
print(new_response.strip())